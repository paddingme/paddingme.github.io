class ApplicationBootStrap {

     def init = { servletContext -> 
       def arthur = new Knight(name:'King Arthur', numDragonsSlain:247L)
       arthur.addToSwords(new Sword(manufacturer:'Excalibur Limited', serialNumber:'XC0000000000'))
       assert arthur.save()

       def lancelot = new Knight(name:'Sir Lancelot', numDragonsSlain:34L)
       lancelot.addToSwords(new Sword(manufacturer:'Wolfgang Puck', serialNumber:'WP0000000001'))
       lancelot.addToSwords(new Sword(manufacturer:'Ginsu', serialNumber:'G20416734'))
       assert lancelot.save()
       
       def bors = new Knight(name:'Sir Bors', numDragonsSlain:5L)
       def puckTwo = new Sword(manufacturer:'Wolfgang Puck', serialNumber:'WP0000000002')
       bors.addToSwords(puckTwo)
       assert bors.save()

       def unassignedSword = new Sword(manufacturer:'Wolfgang Puck', serialNumber:'WP0000000003')
       unassignedSword.save()    
     }

     def destroy = {
     }
} 