class Battle { 
  String name
  String location
  Date date
  
  static hasMany = [knights:Knight]   
}	
