class Knight { 
  String name
  Long numDragonsSlain  

  static hasMany = [swords:Sword, battles:Battle]     
  static belongsTo = Battle
  
  static constraints = {
    name(blank:false, maxSize:30)
    numDragonsSlain(min:0L)
  }
}	
