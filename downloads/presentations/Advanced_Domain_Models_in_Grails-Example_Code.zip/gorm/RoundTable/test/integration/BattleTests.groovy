class BattleTests extends GroovyTestCase {

	void testSavingBattleShouldSaveKnight() {
    def battle = new Battle(name:'Some Fight', date:new Date(), location:'Some hillside')    
    def knight = new Knight(name:'Sir Bors', numDragonsSlain:5L)
    battle.addToKnights(knight).save()

	  assertNotNull knight.id
	  assertNotNull battle.id
	}

	void testSavingKnightShouldNotSaveBattle() {
    def battle = new Battle(name:'Some Fight', date:new Date(), location:'Some hillside')    
    def knight = new Knight(name:'Sir Bors', numDragonsSlain:5L)
    battle.addToKnights(knight).save()

	  assertNotNull knight.id
	  assertNotNull battle.id
	}        
	
	void testShouldAllowOneKnightToHaveManyBattles() {
    def skirmish = new Battle(name:'Small Fight', date:new Date(), location:'Some hillside')    
    def argument = new Battle(name:'Small Fight', date:new Date(), location:'Some valley')    
    def knight = new Knight(name:'Sir Bors', numDragonsSlain:5L)
    skirmish.addToKnights(knight)
    argument.addToKnights(knight)
    assertEquals 2, knight.battles.size()
    assertEquals 1, skirmish.knights.size()
    assertEquals 1, argument.knights.size()
    assert skirmish.save()
    assert argument.save()
	}        

	void testShouldAllowOneBattleToHaveManyKnights() {
    def battle = new Battle(name:'Some Brawl', date:new Date(), location:'Some hillside')    
    def bors = new Knight(name:'Sir Bors', numDragonsSlain:5L)
    def lancelot = new Knight(name:'Sir Lancelot', numDragonsSlain:34L)
    
    battle.addToKnights(bors)
    battle.addToKnights(lancelot)
    assertEquals 2, battle.knights.size()
    assertEquals 1, bors.battles.size()
    assertEquals 1, lancelot.battles.size()
    assert battle.save()
	}        
}
