class KnightTests extends GroovyTestCase {
                              
	void testShouldPreventInvalidName() {       
	  def knight = new Knight(name:'', numDragonsSlain:4)
	  assertFalse knight.validate()

    def nameError = knight.errors.getFieldError('name') 
    assertNotNull nameError.codes.find { it == 'knight.name.blank' } 
	}
	
	void testShouldFindWithDynamicFinders() {   
    new Knight(name:'King Arthur', numDragonsSlain:247L).save()

    def lancelot = new Knight(name:'Sir Lancelot', numDragonsSlain:34L)
    lancelot.addToSwords(new Sword(manufacturer:'Wolfgang Puck', serialNumber:'WP0000000001'))
    lancelot.addToSwords(new Sword(manufacturer:'Ginsu', serialNumber:'G20416734'))
    assert lancelot.save()
    	      
	  assertEquals 1, Knight.findAllByName('King Arthur').size()       
	  assertEquals 1, Knight.findAllByNameLike('King%').size()     
	  assertEquals 1, Knight.findAllByNameAndNumDragonsSlain('King Arthur', 247L).size()     
	  assertEquals 2, Knight.countByNumDragonsSlainGreaterThan(10L)
	  assertEquals 1, Knight.countByNumDragonsSlainGreaterThan(100L)
	  assertEquals 0, Knight.countByNumDragonsSlainGreaterThan(1000L)
	  
	  assertEquals lancelot, Sword.findByManufacturer('Ginsu').knight
	  assertEquals 2, Knight.findByName('Sir Lancelot').swords.size()
	}
	
	void testSavingKnightShouldSaveSword() {
    def lancelot = new Knight(name:'Sir Lancelot', numDragonsSlain:34L)
    lancelot.addToSwords(new Sword(manufacturer:'Wolfgang Puck', serialNumber:'WP0000000001'))
    lancelot.addToSwords(new Sword(manufacturer:'Ginsu', serialNumber:'G20416734'))
    assert lancelot.save()

	  lancelot.swords.each {
	    assertNotNull it.id
	  }
	}
	
	void testSavingSwordShouldNotSaveKnight() {  
    def sword = new Sword(manufacturer:'Wolfgang Puck', serialNumber:'WP0000000001')	  
    def lancelot = new Knight(name:'Sir Lancelot', numDragonsSlain:34L)
    lancelot.addToSwords(sword)
    assertNull sword.id
    assertNull lancelot.id
	}	 
}
