class SwordTests extends GroovyTestCase {

	void testSavingTheCheerleaderShouldSaveTheWorld() {
	  assert true
	}
}
