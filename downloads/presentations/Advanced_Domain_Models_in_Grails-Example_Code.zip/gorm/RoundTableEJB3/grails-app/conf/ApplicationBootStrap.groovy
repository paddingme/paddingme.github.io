import com.jasonrudolph.roundtable.entity.*

class ApplicationBootStrap {

     def init = { servletContext -> 
       def arthur = new Knight(id: 1L, name:'King Arthur', numDragonsSlain:247)
       arthur.addToSwords(new Sword(manufacturer:'Excalibur Limited', serialNumber:'XC0000000000'))
       assert arthur.save()

       def lancelot = new Knight(id: 2L, name:'Sir Lancelot', numDragonsSlain:34)
       lancelot.addToSwords(new Sword(manufacturer:'Wolfgang Puck', serialNumber:'WP0000000001'))
       lancelot.addToSwords(new Sword(manufacturer:'Ginsu', serialNumber:'G20416734'))
       assert lancelot.save()
       
       def bors = new Knight(id: 3L, name:'Sir Bors', numDragonsSlain:5)
       def puckTwo = new Sword(manufacturer:'Wolfgang Puck', serialNumber:'WP0000000002')
       bors.addToSwords(puckTwo)
       assert bors.save()  
     }

     def destroy = {
     }
}