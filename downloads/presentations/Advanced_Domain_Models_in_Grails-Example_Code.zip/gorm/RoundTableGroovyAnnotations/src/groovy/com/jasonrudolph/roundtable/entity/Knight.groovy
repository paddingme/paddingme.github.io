package com.jasonrudolph.roundtable.entity

import java.util.HashSet
import java.util.Set
import javax.persistence.Column
import javax.persistence.Entity
import javax.persistence.FetchType
import javax.persistence.Id
import javax.persistence.OneToMany
import javax.persistence.Table

@Entity
@Table(name="knights")
public class Knight  implements java.io.Serializable {

    @Id 
    @Column(name="knight_id", nullable=false)
    long id
    
    String name
    
    @Column(name="dragon_count", nullable=false)
    int numDragonsSlain

    @OneToMany(fetch=FetchType.LAZY, mappedBy="knight")
    Set<Sword> swords = new HashSet<Sword>(0)  

    static constraints = {
      name(blank:false, maxSize:50)
    }    
}


