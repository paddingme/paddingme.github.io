class Knight {     
  def id // knight_id
  String name
  int numDragonsSlain
  
  static hasMany = [swords:Sword]   
  
  static constraints = {
    name(blank:false, maxSize:30)
    numDragonsSlain(min:0)
  }  
}	
