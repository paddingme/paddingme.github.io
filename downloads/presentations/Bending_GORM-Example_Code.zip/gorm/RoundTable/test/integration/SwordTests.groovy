class SwordTests extends GroovyTestCase {

    void testSomething() {

    }
}
