constraints = {
  name(blank:false, maxSize:50)
}