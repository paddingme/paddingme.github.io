class RaceController {

    def scaffold = Race
}
