class RegistrationControllerTests extends GroovyTestCase {

    void testSomething() {

    }
}
