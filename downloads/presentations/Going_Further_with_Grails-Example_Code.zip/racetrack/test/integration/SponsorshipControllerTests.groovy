class SponsorshipControllerTests extends GroovyTestCase {

    void testSomething() {

    }
}
