class SponsorshipServiceTests extends GroovyTestCase {

    void testSomething() {

    }
}
