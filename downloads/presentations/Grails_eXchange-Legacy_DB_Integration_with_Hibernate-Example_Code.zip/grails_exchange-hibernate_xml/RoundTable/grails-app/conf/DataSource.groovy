dataSource {
	pooled = false
	driverClassName = "com.mysql.jdbc.Driver"
	username = "root"
	password = ""
}
// environment specific settings
environments {
	development {
		dataSource {
			// dbCreate = "update" // one of 'create', 'create-drop','update'
			url = "jdbc:mysql://localhost/round_table_hibernate_unconventional_dev"
		}
	}
	test {
		dataSource {
			dbCreate = "update"
			url = "jdbc:hsqldb:mem:testDb"
		}
	}
	production {
		dataSource {
			dbCreate = "update"
			url = "jdbc:hsqldb:file:prodDb;shutdown=true"
		}
	}
}