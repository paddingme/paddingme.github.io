class Castle { 
    String name
    String country

    Knight knight 
    
    static belongsTo = [Knight]     
}	
