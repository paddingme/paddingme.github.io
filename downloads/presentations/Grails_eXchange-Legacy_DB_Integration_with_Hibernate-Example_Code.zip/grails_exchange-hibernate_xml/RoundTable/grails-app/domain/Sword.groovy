class Sword { 
    String serialNumber
    String manufacturer
    Knight knight
    
    static belongsTo = [Knight]
}	
