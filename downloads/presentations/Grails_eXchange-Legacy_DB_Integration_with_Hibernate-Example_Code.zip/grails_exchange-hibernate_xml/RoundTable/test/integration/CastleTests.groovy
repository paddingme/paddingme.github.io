class CastleTests extends GroovyTestCase {

    void testSomething() {

    }
}