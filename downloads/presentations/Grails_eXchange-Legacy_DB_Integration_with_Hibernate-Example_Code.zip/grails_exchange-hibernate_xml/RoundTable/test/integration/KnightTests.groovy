class KnightTests extends GroovyTestCase {

	void testSomething() {
		
	}
}
